import 'package:flutter/material.dart';

import 'models/app_role.dart';
import 'screens/login_screen.dart';
import 'screens/unlock_screen.dart';
import 'services/app_lock_service.dart';
import 'services/auth_session_service.dart';
import 'theme/app_colors.dart';
import 'theme/app_theme.dart';

void main() {
  runApp(const BuidArchApp());
}

class BuidArchApp extends StatelessWidget {
  const BuidArchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Build Arch',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: const _StartupGate(),
    );
  }
}

/// Decides the first screen: returning users with app lock turned on see
/// the unlock screen, everyone else sees the login screen.
class _StartupGate extends StatefulWidget {
  const _StartupGate();

  @override
  State<_StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<_StartupGate> {
  late final Future<_StartupState> _startup = _loadStartupState();

  Future<_StartupState> _loadStartupState() async {
    final lockEnabled = await AppLockService.instance.isEnabled();
    final isLoggedIn = await AuthSessionService.instance.isLoggedIn();
    final user =
        isLoggedIn ? await AuthSessionService.instance.readUser() : null;
    return _StartupState(
      lockEnabled: lockEnabled,
      isLoggedIn: isLoggedIn,
      userName: _userName(user?['name']),
      userRole: _userRole(user?['role']),
    );
  }

  String _userName(Object? name) {
    if (name is String && name.trim().isNotEmpty) return name.trim();
    return 'Build Arch User';
  }

  String _userRole(Object? role) {
    if (role is String) {
      for (final appRole in AppRole.values) {
        if (appRole.name == role) return appRole.label;
      }
      if (role == 'architect' ||
          role == 'engineer' ||
          role == 'interiorDesigner') {
        return AppRole.designer.label;
      }
    }
    return 'Build Arch Member';
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_StartupState>(
      future: _startup,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const LoginScreen();
        }
        if (!snapshot.hasData) {
          return const Scaffold(
            backgroundColor: AppColors.deepBrown,
            body: Center(
              child: CircularProgressIndicator(color: AppColors.creamSand),
            ),
          );
        }

        final state = snapshot.data!;
        if (state.isLoggedIn && state.lockEnabled) {
          return UnlockScreen(
            userName: state.userName,
            userRole: state.userRole,
          );
        }

        return const LoginScreen();
      },
    );
  }
}

class _StartupState {
  const _StartupState({
    required this.lockEnabled,
    required this.isLoggedIn,
    required this.userName,
    required this.userRole,
  });

  final bool lockEnabled;
  final bool isLoggedIn;
  final String userName;
  final String userRole;
}
