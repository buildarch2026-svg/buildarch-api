import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

import '../models/project.dart';
import '../models/project_type.dart';

class AuthApiException implements Exception {
  const AuthApiException(this.message);

  final String message;

  @override
  String toString() => message;
}

class AuthApiService {
  AuthApiService({http.Client? client}) : _client = client ?? http.Client();

  static final instance = AuthApiService();
  static const _baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8000/api',
  );
  static const _timeout = Duration(seconds: 15);

  final http.Client _client;

  Future<void> requestOtp(String phoneNumber) async {
    await _post('/auth/otp/request', {
      'phone_number': _normalizePhoneNumber(phoneNumber),
    });
  }

  Future<void> verifyProfilePhone({
    required String token,
    required String phoneNumber,
    required String code,
  }) async {
    final response = await _post(
      '/user/profile/phone/verify',
      {
        'phone_number': _normalizePhoneNumber(phoneNumber),
        'code': code,
      },
      headers: {'Authorization': 'Bearer $token'},
    );
    if (response['verified'] != true) {
      throw const AuthApiException('The mobile number was not verified.');
    }
  }

  Future<Map<String, dynamic>> verifyOtp({
    required String phoneNumber,
    required String code,
  }) async {
    final response = await _post('/auth/otp/verify', {
      'phone_number': _normalizePhoneNumber(phoneNumber),
      'code': code,
    });

    if (response['verified'] != true) {
      throw const AuthApiException('The verification code was not accepted.');
    }

    return response;
  }

  Future<Map<String, dynamic>> getCurrentUser({required String token}) async {
    final response = await _get('/user', headers: {
      'Authorization': 'Bearer $token',
    });

    if (response['id'] == null) {
      throw const AuthApiException('The saved session is no longer valid.');
    }

    return response;
  }

  Future<Map<String, dynamic>> updateProfile({
    required String token,
    required String name,
    required String location,
    required String role,
  }) async {
    final response = await _patch('/user/profile', {
      'name': name,
      'location': location,
      'role': role,
    }, headers: {
      'Authorization': 'Bearer $token',
    });

    final user = response['user'];
    if (user is Map<String, dynamic>) return user;
    if (user is Map) return Map<String, dynamic>.from(user);
    throw const AuthApiException('The profile response was invalid.');
  }

  Future<List<Project>> getProjects({required String token}) async {
    final response = await _get('/projects', headers: {
      'Authorization': 'Bearer $token',
    });
    final projects = response['projects'];
    if (projects is! List) {
      throw const AuthApiException('The projects response was invalid.');
    }

    try {
      return projects.map((project) {
        if (project is Map<String, dynamic>) {
          return Project.fromJson(project);
        }
        if (project is Map) {
          return Project.fromJson(Map<String, dynamic>.from(project));
        }
        throw const FormatException('The project response was invalid.');
      }).toList();
    } on FormatException catch (error) {
      throw AuthApiException(error.message);
    }
  }

  Future<Project> createProject({
    required String token,
    required String name,
    required String location,
    required ProjectType type,
    XFile? photo,
  }) async {
    if (photo != null) {
      final response = await _postMultipart(
        '/projects',
        {
          'name': name,
          'location': location,
          'type': type.apiValue,
        },
        photo: photo,
        headers: {'Authorization': 'Bearer $token'},
      );
      return _projectFromResponse(response);
    }

    final response = await _post(
      '/projects',
      {
        'name': name,
        'location': location,
        'type': type.apiValue,
      },
      headers: {'Authorization': 'Bearer $token'},
    );

    return _projectFromResponse(response);
  }

  Project _projectFromResponse(Map<String, dynamic> response) {
    final project = response['project'];
    if (project is Map<String, dynamic>) {
      try {
        return Project.fromJson(project);
      } on FormatException catch (error) {
        throw AuthApiException(error.message);
      }
    }
    if (project is Map) {
      try {
        return Project.fromJson(Map<String, dynamic>.from(project));
      } on FormatException catch (error) {
        throw AuthApiException(error.message);
      }
    }
    throw const AuthApiException('The project response was invalid.');
  }

  Future<Map<String, dynamic>> _postMultipart(
    String path,
    Map<String, String> fields, {
    required XFile photo,
    Map<String, String> headers = const {},
  }) async {
    final baseUrl = _baseUrl.endsWith('/') ? _baseUrl : '$_baseUrl/';
    final uri =
        Uri.parse(baseUrl).resolve(path.replaceFirst(RegExp(r'^/'), ''));
    final request = http.MultipartRequest('POST', uri)
      ..headers.addAll({'Accept': 'application/json', ...headers})
      ..fields.addAll(fields)
      ..files.add(
        http.MultipartFile.fromBytes(
          'photo',
          await photo.readAsBytes(),
          filename: photo.name,
        ),
      );

    try {
      final streamedResponse = await _client.send(request).timeout(_timeout);
      final response = await http.Response.fromStream(streamedResponse)
          .timeout(_timeout);
      return _decodeResponse(response);
    } on SocketException {
      throw const AuthApiException(
        'Cannot reach the API. Check that Laravel is running and the API URL is correct.',
      );
    } on TimeoutException {
      throw const AuthApiException('The API request timed out. Try again.');
    } on http.ClientException {
      throw const AuthApiException(
        'Could not connect to the API. Check the device network and API URL.',
      );
    }
  }

  Future<Map<String, dynamic>> signInWithGoogle({
    required String email,
    required String name,
    required String googleId,
    String? idToken,
  }) async {
    final payload = <String, dynamic>{
      'email': email,
      'name': name,
      'google_id': googleId,
    };

    if (idToken != null && idToken.trim().isNotEmpty) {
      payload['id_token'] = idToken;
    }

    final response = await _post('/auth/google', payload);

    if (response['verified'] != true) {
      throw const AuthApiException('Google sign-in was not accepted.');
    }

    return response;
  }

  Future<Map<String, dynamic>> _post(
    String path,
    Map<String, dynamic> body, {
    Map<String, String> headers = const {},
  }) async {
    final baseUrl = _baseUrl.endsWith('/') ? _baseUrl : '$_baseUrl/';
    final uri =
        Uri.parse(baseUrl).resolve(path.replaceFirst(RegExp(r'^/'), ''));
    late final http.Response response;

    try {
      response = await _client
          .post(
            uri,
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              ...headers,
            },
            body: jsonEncode(body),
          )
          .timeout(_timeout);
    } on SocketException {
      throw const AuthApiException(
        'Cannot reach the API. Check that Laravel is running and the API URL is correct.',
      );
    } on TimeoutException {
      throw const AuthApiException('The API request timed out. Try again.');
    } on http.ClientException {
      throw const AuthApiException(
        'Could not connect to the API. Check the device network and API URL.',
      );
    }

    return _decodeResponse(response);
  }

  Future<Map<String, dynamic>> _get(
    String path, {
    Map<String, String> headers = const {},
  }) async {
    final baseUrl = _baseUrl.endsWith('/') ? _baseUrl : '$_baseUrl/';
    final uri =
        Uri.parse(baseUrl).resolve(path.replaceFirst(RegExp(r'^/'), ''));
    late final http.Response response;

    try {
      response = await _client.get(
        uri,
        headers: {
          'Accept': 'application/json',
          ...headers,
        },
      ).timeout(_timeout);
    } on SocketException {
      throw const AuthApiException(
        'Cannot reach the API. Check that Laravel is running and the API URL is correct.',
      );
    } on TimeoutException {
      throw const AuthApiException('The API request timed out. Try again.');
    } on http.ClientException {
      throw const AuthApiException(
        'Could not connect to the API. Check the device network and API URL.',
      );
    }

    return _decodeResponse(response);
  }

  Future<Map<String, dynamic>> _patch(
    String path,
    Map<String, dynamic> body, {
    Map<String, String> headers = const {},
  }) async {
    final baseUrl = _baseUrl.endsWith('/') ? _baseUrl : '$_baseUrl/';
    final uri =
        Uri.parse(baseUrl).resolve(path.replaceFirst(RegExp(r'^/'), ''));
    late final http.Response response;

    try {
      response = await _client
          .patch(
            uri,
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              ...headers,
            },
            body: jsonEncode(body),
          )
          .timeout(_timeout);
    } on SocketException {
      throw const AuthApiException(
        'Cannot reach the API. Check that Laravel is running and the API URL is correct.',
      );
    } on TimeoutException {
      throw const AuthApiException('The API request timed out. Try again.');
    } on http.ClientException {
      throw const AuthApiException(
        'Could not connect to the API. Check the device network and API URL.',
      );
    }

    return _decodeResponse(response);
  }

  Map<String, dynamic> _decodeResponse(http.Response response) {
    Map<String, dynamic> data = {};
    try {
      final decoded = jsonDecode(response.body);
      if (decoded is Map<String, dynamic>) {
        data = decoded;
      } else if (decoded is Map) {
        data = Map<String, dynamic>.from(decoded);
      }
    } on FormatException {
      // Keep the response as an HTTP error if Laravel returned non-JSON output.
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw AuthApiException(_messageFrom(data));
    }

    return data;
  }

  String _normalizePhoneNumber(String phoneNumber) {
    final normalized = phoneNumber.replaceAll(RegExp(r'[\s()-]'), '');
    if (!RegExp(r'^\+[1-9]\d{7,14}$').hasMatch(normalized)) {
      throw const AuthApiException('Enter a valid international phone number.');
    }
    return normalized;
  }

  String _messageFrom(Map<String, dynamic> data) {
    final errors = data['errors'];
    if (errors is Map<String, dynamic>) {
      for (final value in errors.values) {
        if (value is List && value.isNotEmpty) return value.first.toString();
      }
    }

    final message = data['message'];
    if (message is String && message.isNotEmpty) return message;
    return 'The request failed. Please try again.';
  }
}
