import 'package:flutter/material.dart';

import 'projects_screen.dart';

/// Keeps the existing post-login route while opening the projects experience.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const ProjectsScreen();
  }
}
