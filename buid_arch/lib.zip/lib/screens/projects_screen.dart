import 'package:flutter/material.dart';

import '../services/auth_session_service.dart';
import '../services/projects_store.dart';
import '../theme/app_colors.dart';
import '../theme/app_text_styles.dart';
import '../widgets/auth_button.dart';
import '../widgets/project_card.dart';
import 'create_project_screen.dart';
import 'profile_screen.dart';

/// "Your Projects" - the home owner's landing screen after login/unlock.
/// Shows an empty state until the first project is created.
class ProjectsScreen extends StatefulWidget {
  const ProjectsScreen({super.key});

  @override
  State<ProjectsScreen> createState() => _ProjectsScreenState();
}

class _ProjectsScreenState extends State<ProjectsScreen> {
  @override
  void initState() {
    super.initState();
    ProjectsStore.instance.addListener(_onStoreChanged);
    ProjectsStore.instance.load(refresh: true);
  }

  @override
  void dispose() {
    ProjectsStore.instance.removeListener(_onStoreChanged);
    super.dispose();
  }

  void _onStoreChanged() => setState(() {});

  void _openCreateProject() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const CreateProjectScreen()),
    );
  }

  void _comingSoon(String what) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text('$what - coming soon')));
  }

  Future<void> _openProfile() async {
    try {
      final user = await AuthSessionService.instance.readUser();
      if (!mounted) return;
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ProfileScreen(user: user ?? const {}),
        ),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          const SnackBar(content: Text('Could not load your profile.')),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = ProjectsStore.instance;

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        surfaceTintColor: AppColors.surface,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Text(
          'Projects',
          style: AppTextStyles.cardTitle.copyWith(
            fontSize: 18,
            color: AppColors.textPrimary,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => _comingSoon('Notifications'),
            icon: const Icon(Icons.notifications_none,
                color: AppColors.onSurfaceVariant),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 12, left: 4),
            child: IconButton(
              tooltip: 'View profile',
              onPressed: _openProfile,
              icon: Container(
                width: 32,
                height: 32,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.primaryContainer,
                ),
                child: const Icon(Icons.person, size: 18, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
      body: SafeArea(
        top: false,
        child: store.isLoading
            ? const Center(
                child: CircularProgressIndicator(color: AppColors.primary),
              )
            : store.errorMessage != null
                ? _buildLoadError(store.errorMessage!)
                : store.isEmpty
                    ? _buildEmptyState()
                    : _buildList(store),
      ),
    );
  }

  Widget _buildLoadError(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_outlined,
                size: 44, color: AppColors.outline),
            const SizedBox(height: 12),
            Text(
              message,
              textAlign: TextAlign.center,
              style: AppTextStyles.bodyMd.copyWith(
                color: AppColors.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () => ProjectsStore.instance.load(refresh: true),
              child: const Text('Try again'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildList(ProjectsStore store) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Your Projects',
              style: AppTextStyles.cardTitle.copyWith(
                fontSize: 18,
                color: AppColors.textPrimary,
              ),
            ),
            _createButton(),
          ],
        ),
        const SizedBox(height: 16),
        for (final project in store.projects) ...[
          ProjectCard(
            project: project,
            onTap: () => _comingSoon('${project.name} dashboard'),
          ),
          const SizedBox(height: 12),
        ],
      ],
    );
  }

  Widget _buildEmptyState() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Your Projects',
              style: AppTextStyles.cardTitle.copyWith(
                fontSize: 18,
                color: AppColors.textPrimary,
              ),
            ),
            _createButton(),
          ],
        ),
        const SizedBox(height: 48),
        Center(
          child: Container(
            width: 120,
            height: 120,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.surfaceContainer,
            ),
            child: const Icon(Icons.architecture,
                size: 52, color: AppColors.secondary),
          ),
        ),
        const SizedBox(height: 24),
        Text(
          'No Projects Yet',
          textAlign: TextAlign.center,
          style: AppTextStyles.cardTitle.copyWith(
            fontSize: 18,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 280),
            child: Text(
              'Create your first project to start inviting your team and '
              'tracking progress.',
              textAlign: TextAlign.center,
              style: AppTextStyles.bodyMd.copyWith(
                color: AppColors.outline,
                height: 1.4,
              ),
            ),
          ),
        ),
        const SizedBox(height: 32),
        AuthButton(
          label: 'Create Project',
          onPressed: _openCreateProject,
          backgroundColor: AppColors.primaryContainer,
          pressedColor: AppColors.primary.withAlpha(90),
          textStyle: AppTextStyles.titleMd.copyWith(color: Colors.white),
          leading: const Icon(Icons.add, size: 20, color: Colors.white),
        ),
        const SizedBox(height: 10),
        AuthButton(
          label: 'Join an Existing Project',
          onPressed: () => _comingSoon('Join with QR code'),
          backgroundColor: AppColors.surfaceContainerLow,
          pressedColor: AppColors.surfaceContainer,
          textStyle: AppTextStyles.bodyMd.copyWith(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppColors.textPrimary,
          ),
          leading: const Icon(Icons.qr_code_scanner,
              size: 20, color: AppColors.onSurfaceVariant),
          shadows: const [],
        ),
        const SizedBox(height: 20),
        _tipCard(),
      ],
    );
  }

  Widget _createButton() {
    return InkWell(
      onTap: _openCreateProject,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        width: 40,
        height: 40,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: AppColors.primaryContainer,
          boxShadow: [
            BoxShadow(
              color: Color(0x338B5200),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: const Icon(Icons.add, size: 20, color: Colors.white),
      ),
    );
  }

  Widget _tipCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.surfaceContainer,
            ),
            child: const Icon(Icons.lightbulb_outline,
                size: 20, color: AppColors.secondary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Architect's Tip",
                  style: AppTextStyles.bodyMd.copyWith(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 13 * 0.04,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Invite structural and interior teams early for '
                  'real-time approvals.',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.bodySm
                      .copyWith(color: AppColors.onSurfaceVariant),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
