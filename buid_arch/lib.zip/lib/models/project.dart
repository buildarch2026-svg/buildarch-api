import 'project_type.dart';

class Project {
  Project({
    required this.id,
    required this.name,
    required this.location,
    required this.type,
    this.progress = 0,
    this.photoUrl,
  });

  final String id;
  final String name;
  final String location;
  final ProjectType type;

  /// 0.0 - 1.0
  final double progress;
  final String? photoUrl;

  factory Project.fromJson(Map<String, dynamic> json) {
    final id = json['id'];
    final name = json['name'];
    final location = json['location'];
    final typeValue = json['type'];

    if (id == null ||
        name is! String ||
        location is! String ||
        typeValue is! String) {
      throw const FormatException('The project response was invalid.');
    }

    final type = ProjectType.values.where(
      (value) => value.apiValue == typeValue,
    );
    if (type.isEmpty) {
      throw const FormatException('The project type was invalid.');
    }

    final progress = json['progress'];
    return Project(
      id: id.toString(),
      name: name,
      location: location,
      type: type.first,
      progress: progress is num ? progress.toDouble() : 0,
      photoUrl: json['photo_url'] is String
          ? json['photo_url'] as String
          : null,
    );
  }
}
